"""
接口层模块
从williw-master获取节点信息
提供客户端示例
"""
